﻿Public Class UserSettings

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        My.Settings.MirrorWarning = True
        My.Settings.Save()
        Label1.Text = "MirrorWarning=" & My.Settings.MirrorWarning.ToString
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        My.Settings.MirrorWarning = False
        My.Settings.Save()
        Label1.Text = "MirrorWarning=" & My.Settings.MirrorWarning.ToString
    End Sub

    Private Sub UserSettings_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Set form style defaults
        Application.EnableVisualStyles()

        ' Load user settings
        Label1.Text = "MirrorWarning=" & My.Settings.MirrorWarning.ToString

    End Sub
End Class