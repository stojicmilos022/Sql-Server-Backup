﻿Public Class MirrorWarning
    Public MirrorCopy As Boolean
    ' Ideally the Messagebox class should be adequate to display a message. Unfortunately as at the
    ' time of coding the Messagebox class does not have a "Dont show this message again" feature. So
    ' this form solves that problem.
    Private Sub YesButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles YesButton.Click
        MirrorCopy = True
        Me.Hide()
    End Sub

    Private Sub NoButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NoButton.Click
        MirrorCopy = False
        Me.Hide()
    End Sub
    Private Sub MirrorWarning_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If MirrorWarnCheckBox.Checked Then
            My.Settings.MirrorWarning = False
            My.Settings.Save()
        End If
    End Sub
    Private Sub MirrorWarning_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim Message As String = "You have selected a mirror copy. This will delete files in "
        Message += "the " & """" & "To Folder " & """" & " in order to mirror the " & """" & "From Folder" & """" & ". "
        Message += "If you have selected the wrong folders you could end up deleting wanted files unintentionally, possibly "
        Message += "deleting all the data you need and rendering your computer inoperable. "
        Message += "So use the mirror option at your own risk! " & vbCrLf & vbCrLf
        Message += "Check your " & """" & "From Folder" & """" & " and " & """" & "To Folder" & """" & " parameters are correct before you proceed. "
        Message += vbCrLf & vbCrLf
        Message += "If you are unsure what this message means then press the " & """" & "No" & """" & " button and then press the " & """" & "Help" & """" & " button for more information." & vbCrLf & vbCrLf

        TextBox1.Text = Message

        Me.CenterToScreen()

    End Sub
End Class