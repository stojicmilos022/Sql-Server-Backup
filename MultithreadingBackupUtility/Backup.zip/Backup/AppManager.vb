﻿Public Class AppManager

    <STAThread()> _
    Shared Sub Main()
        ' Set form style defaults
        Application.EnableVisualStyles()
        Application.SetCompatibleTextRenderingDefault(False)

        ' Test for command line parameters.
        If Environment.GetCommandLineArgs.Length > 1 Then
            ' If in batch mode just instantiate the FileCopy class as no form is needed.
            ' Also don't declare this class "withevents" as the events only report status
            ' data (like the number of files copied so far).
            Dim BatchCopy As New FileCopy

            ' Setup the copy parameters for the BatchCopy instance from command line arguments
            Dim Argument As String
            Dim Index As Integer = 0
            For Each Argument In Environment.GetCommandLineArgs
                Select Case Index
                    Case 0
                        ' The first argument is the app file/path so do nothing
                    Case 1
                        BatchCopy.FromPath = Environment.GetCommandLineArgs(1).ToString
                    Case 2
                        BatchCopy.ToPath = Environment.GetCommandLineArgs(2).ToString
                    Case 3
                        If Environment.GetCommandLineArgs(3).ToString.ToUpper = "TRUE" Then
                            BatchCopy.MirrorCopy = True
                        Else
                            BatchCopy.MirrorCopy = False
                        End If
                    Case 4
                        If Environment.GetCommandLineArgs(4).ToString.ToUpper = "TRUE" Then
                            BatchCopy.QuietLog = True
                        Else
                            BatchCopy.QuietLog = False
                        End If
                    Case Else
                        ' Ignore any remaining arguments as something is wrong. The BatchCopy class
                        ' will log any errors in the log file.
                End Select
                Index += 1
            Next

            ' Start the multithreaded copy 
            BatchCopy.InitialMessage = "*** MODE IS BATCH ***"
            If BatchCopy.MirrorCopy Then
                BatchCopy.InitialMessage = "*** MODE IS BATCH - MIRROR COPY IS SET ***"
            End If
            If BatchCopy.QuietLog Then
                BatchCopy.InitialMessage += vbCrLf & "Logging is quiet - not verbose."
            Else
                BatchCopy.InitialMessage += vbCrLf & "Logging is not quiet - its verbose."
            End If
            BatchCopy.BatchCopy = True
            BatchCopy.StartCopy()

            BatchCopy.WaitForThreads()
        Else
            ' Forms mode so open the Backup form. The Backup from will instantiate the FileCopy class
            ' when the "Go" button is pressed.
            Dim BackupForm As Backup
            BackupForm = New Backup()
            Application.Run(BackupForm)
        End If

    End Sub

End Class
