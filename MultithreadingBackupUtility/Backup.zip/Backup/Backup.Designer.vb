<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Backup
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Backup))
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.QuietLog = New System.Windows.Forms.CheckBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.MirrorCopy = New System.Windows.Forms.CheckBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.BrowseTo = New System.Windows.Forms.Button
        Me.ToPathTextbox = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.BrowseFrom = New System.Windows.Forms.Button
        Me.FromPathTextbox = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.WorkingLabel = New System.Windows.Forms.Label
        Me.WorkingBar = New System.Windows.Forms.ProgressBar
        Me.FileStatusTextbox = New System.Windows.Forms.TextBox
        Me.CopyStatusLabel = New System.Windows.Forms.Label
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar
        Me.StartCopy = New System.Windows.Forms.Button
        Me.StopCopy = New System.Windows.Forms.Button
        Me.ViewLog = New System.Windows.Forms.Button
        Me.Label3 = New System.Windows.Forms.Label
        Me.Help = New System.Windows.Forms.Button
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.QuietLog)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.MirrorCopy)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.BrowseTo)
        Me.Panel1.Controls.Add(Me.ToPathTextbox)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.BrowseFrom)
        Me.Panel1.Controls.Add(Me.FromPathTextbox)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.ForeColor = System.Drawing.Color.Blue
        Me.Panel1.Location = New System.Drawing.Point(7, 19)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(609, 73)
        Me.Panel1.TabIndex = 6
        '
        'QuietLog
        '
        Me.QuietLog.AutoSize = True
        Me.QuietLog.Location = New System.Drawing.Point(205, 52)
        Me.QuietLog.Name = "QuietLog"
        Me.QuietLog.Size = New System.Drawing.Size(15, 14)
        Me.QuietLog.TabIndex = 19
        Me.QuietLog.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(123, 52)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(76, 13)
        Me.Label5.TabIndex = 18
        Me.Label5.Text = "Quiet Logging:"
        '
        'MirrorCopy
        '
        Me.MirrorCopy.AutoSize = True
        Me.MirrorCopy.Location = New System.Drawing.Point(84, 52)
        Me.MirrorCopy.Name = "MirrorCopy"
        Me.MirrorCopy.Size = New System.Drawing.Size(15, 14)
        Me.MirrorCopy.TabIndex = 17
        Me.MirrorCopy.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(0, 52)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(63, 13)
        Me.Label4.TabIndex = 16
        Me.Label4.Text = "Mirror Copy:"
        '
        'BrowseTo
        '
        Me.BrowseTo.Location = New System.Drawing.Point(528, 28)
        Me.BrowseTo.Name = "BrowseTo"
        Me.BrowseTo.Size = New System.Drawing.Size(75, 23)
        Me.BrowseTo.TabIndex = 11
        Me.BrowseTo.Text = "Browse"
        Me.BrowseTo.UseVisualStyleBackColor = True
        '
        'ToPathTextbox
        '
        Me.ToPathTextbox.Location = New System.Drawing.Point(84, 28)
        Me.ToPathTextbox.Name = "ToPathTextbox"
        Me.ToPathTextbox.ReadOnly = True
        Me.ToPathTextbox.Size = New System.Drawing.Size(436, 20)
        Me.ToPathTextbox.TabIndex = 10
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(0, 32)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(55, 13)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "To Folder:"
        '
        'BrowseFrom
        '
        Me.BrowseFrom.Location = New System.Drawing.Point(528, 2)
        Me.BrowseFrom.Name = "BrowseFrom"
        Me.BrowseFrom.Size = New System.Drawing.Size(75, 23)
        Me.BrowseFrom.TabIndex = 8
        Me.BrowseFrom.Text = "Browse"
        Me.BrowseFrom.UseVisualStyleBackColor = True
        '
        'FromPathTextbox
        '
        Me.FromPathTextbox.Location = New System.Drawing.Point(84, 4)
        Me.FromPathTextbox.Name = "FromPathTextbox"
        Me.FromPathTextbox.ReadOnly = True
        Me.FromPathTextbox.Size = New System.Drawing.Size(436, 20)
        Me.FromPathTextbox.TabIndex = 7
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(0, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(65, 13)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "From Folder:"
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.WorkingLabel)
        Me.Panel2.Controls.Add(Me.WorkingBar)
        Me.Panel2.Controls.Add(Me.FileStatusTextbox)
        Me.Panel2.Controls.Add(Me.CopyStatusLabel)
        Me.Panel2.Controls.Add(Me.ProgressBar1)
        Me.Panel2.Location = New System.Drawing.Point(7, 97)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(609, 135)
        Me.Panel2.TabIndex = 9
        '
        'WorkingLabel
        '
        Me.WorkingLabel.AutoSize = True
        Me.WorkingLabel.Location = New System.Drawing.Point(486, 11)
        Me.WorkingLabel.Name = "WorkingLabel"
        Me.WorkingLabel.Size = New System.Drawing.Size(50, 13)
        Me.WorkingLabel.TabIndex = 17
        Me.WorkingLabel.Text = "Working:"
        Me.WorkingLabel.Visible = False
        '
        'WorkingBar
        '
        Me.WorkingBar.Enabled = False
        Me.WorkingBar.Location = New System.Drawing.Point(536, 13)
        Me.WorkingBar.MarqueeAnimationSpeed = 200
        Me.WorkingBar.Name = "WorkingBar"
        Me.WorkingBar.Size = New System.Drawing.Size(65, 11)
        Me.WorkingBar.Style = System.Windows.Forms.ProgressBarStyle.Marquee
        Me.WorkingBar.TabIndex = 16
        Me.WorkingBar.Visible = False
        '
        'FileStatusTextbox
        '
        Me.FileStatusTextbox.BackColor = System.Drawing.SystemColors.Control
        Me.FileStatusTextbox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.FileStatusTextbox.Location = New System.Drawing.Point(5, 56)
        Me.FileStatusTextbox.Multiline = True
        Me.FileStatusTextbox.Name = "FileStatusTextbox"
        Me.FileStatusTextbox.ReadOnly = True
        Me.FileStatusTextbox.Size = New System.Drawing.Size(596, 72)
        Me.FileStatusTextbox.TabIndex = 10
        '
        'CopyStatusLabel
        '
        Me.CopyStatusLabel.AutoSize = True
        Me.CopyStatusLabel.Location = New System.Drawing.Point(3, 11)
        Me.CopyStatusLabel.Name = "CopyStatusLabel"
        Me.CopyStatusLabel.Size = New System.Drawing.Size(97, 13)
        Me.CopyStatusLabel.TabIndex = 9
        Me.CopyStatusLabel.Text = "Status: Not Started"
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(5, 27)
        Me.ProgressBar1.Maximum = 0
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(596, 23)
        Me.ProgressBar1.TabIndex = 8
        '
        'StartCopy
        '
        Me.StartCopy.Enabled = False
        Me.StartCopy.Location = New System.Drawing.Point(537, 237)
        Me.StartCopy.Name = "StartCopy"
        Me.StartCopy.Size = New System.Drawing.Size(80, 23)
        Me.StartCopy.TabIndex = 10
        Me.StartCopy.Text = "Go"
        Me.StartCopy.UseVisualStyleBackColor = True
        '
        'StopCopy
        '
        Me.StopCopy.Enabled = False
        Me.StopCopy.Location = New System.Drawing.Point(453, 237)
        Me.StopCopy.Name = "StopCopy"
        Me.StopCopy.Size = New System.Drawing.Size(80, 23)
        Me.StopCopy.TabIndex = 11
        Me.StopCopy.Text = "Cancel Copy"
        Me.StopCopy.UseVisualStyleBackColor = True
        '
        'ViewLog
        '
        Me.ViewLog.Enabled = False
        Me.ViewLog.Location = New System.Drawing.Point(7, 236)
        Me.ViewLog.Name = "ViewLog"
        Me.ViewLog.Size = New System.Drawing.Size(75, 23)
        Me.ViewLog.TabIndex = 12
        Me.ViewLog.Text = "View Logfile"
        Me.ViewLog.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(498, 2)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(117, 13)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "Version 2.1.0 by Taner!"
        '
        'Help
        '
        Me.Help.Location = New System.Drawing.Point(88, 236)
        Me.Help.Name = "Help"
        Me.Help.Size = New System.Drawing.Size(75, 23)
        Me.Help.TabIndex = 14
        Me.Help.Text = "Help"
        Me.Help.UseVisualStyleBackColor = True
        '
        'Backup
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(624, 265)
        Me.Controls.Add(Me.Help)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.ViewLog)
        Me.Controls.Add(Me.StopCopy)
        Me.Controls.Add(Me.StartCopy)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Backup"
        Me.Text = "Backup -  Disk to Disk"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents FolderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents BrowseTo As System.Windows.Forms.Button
    Friend WithEvents ToPathTextbox As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents BrowseFrom As System.Windows.Forms.Button
    Friend WithEvents FromPathTextbox As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents CopyStatusLabel As System.Windows.Forms.Label
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents StartCopy As System.Windows.Forms.Button
    Friend WithEvents StopCopy As System.Windows.Forms.Button
    Friend WithEvents FileStatusTextbox As System.Windows.Forms.TextBox
    Friend WithEvents ViewLog As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Help As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents MirrorCopy As System.Windows.Forms.CheckBox
    Friend WithEvents QuietLog As System.Windows.Forms.CheckBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents WorkingBar As System.Windows.Forms.ProgressBar
    Friend WithEvents WorkingLabel As System.Windows.Forms.Label

End Class
