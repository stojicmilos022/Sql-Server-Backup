﻿Imports System.IO

Public Class Logger

    ' Property variables
    Private _logFile As StreamWriter
    Private _startDateTime As Date
    Private _logFileName As String
    Private _fromPath As String
    Private _toPath As String
    Private _message As String

    ' Constants
    Private Const LOG_FILE As String = "Log.txt"
    Private Const ERR_MSG As String = "Error accessing file: "
    Friend Sub OpenLog()

        If _startDateTime = Nothing Then _startDateTime = Now
        If _logFileName = "" Then _logFileName = Format(_startDateTime, "yyMMdd-hhmmss") & "-" & LOG_FILE

        ' Create log file
        If Not File.Exists(_startDateTime & "-" & LOG_FILE) Then
            Using _logFile As StreamWriter = File.CreateText(_logFileName)
                _logFile.WriteLine("Logfile name is: " & _logFileName)
                _logFile.WriteLine("LOG FILE STARTED AT: " & _startDateTime.ToString)
                _logFile.WriteLine("============================================")
                _logFile.Write(_message)
                _logFile.WriteLine()
                _logFile.Close()
            End Using
        End If

    End Sub
    Friend Sub WriteLog()

        ' Create an instance of StreamWriter to write text to a file.
        Using _logFile As StreamWriter = File.AppendText(_logFileName)
            ' Add some text to the file.
            _logFile.WriteLine()
            _logFile.WriteLine("TIME OF LOG ENTRY: " & DateTime.Now)
            ' Arbitrary objects can also be written to the file.
            _logFile.WriteLine(_message)
            _logFile.Flush()
            _logFile.Close()
        End Using

    End Sub
    Public Property LogFileName() As String

        Get
            Return Format(StartDateTime, "yyMMdd-hhmmss") & "-" & LOG_FILE
        End Get
        Set(ByVal value As String)
            _logFileName = value
        End Set

    End Property
    Public Property StartDateTime() As Date

        Get
            Return _startDateTime
        End Get
        Set(ByVal value As Date)
            _startDateTime = value
        End Set

    End Property
    Public Property Message() As String

        Get
            Return _message
        End Get
        Set(ByVal value As String)
            _message = value
        End Set

    End Property
End Class
