﻿namespace In_FormoBackup
{
    partial class Test
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.cmbServer = new System.Windows.Forms.ComboBox();
            this.Server = new System.Windows.Forms.Label();
            this.gbParametri = new System.Windows.Forms.GroupBox();
            this.txtUser = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtWS = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.chbBaze = new System.Windows.Forms.CheckedListBox();
            this.btnSnimi = new System.Windows.Forms.Button();
            this.btnTest = new System.Windows.Forms.Button();
            this.gbBackup = new System.Windows.Forms.GroupBox();
            this.gbBaze = new System.Windows.Forms.GroupBox();
            this.txtPass = new System.Windows.Forms.TextBox();
            this.dtTime = new System.Windows.Forms.DateTimePicker();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.gbMail = new System.Windows.Forms.GroupBox();
            this.txtMail = new System.Windows.Forms.TextBox();
            this.cbDone = new System.Windows.Forms.CheckBox();
            this.cbFail = new System.Windows.Forms.CheckBox();
            this.labMail = new System.Windows.Forms.Label();
            this.gbLokacije = new System.Windows.Forms.GroupBox();
            this.dgLokacije = new System.Windows.Forms.DataGridView();
            this.Lokacija = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.User = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Password = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnBackup = new System.Windows.Forms.Button();
            this.gbParametri.SuspendLayout();
            this.gbBackup.SuspendLayout();
            this.gbBaze.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.gbMail.SuspendLayout();
            this.gbLokacije.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgLokacije)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbServer
            // 
            this.cmbServer.FormattingEnabled = true;
            this.cmbServer.Location = new System.Drawing.Point(109, 19);
            this.cmbServer.Name = "cmbServer";
            this.cmbServer.Size = new System.Drawing.Size(247, 24);
            this.cmbServer.Sorted = true;
            this.cmbServer.TabIndex = 0;
            this.cmbServer.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // Server
            // 
            this.Server.AutoSize = true;
            this.Server.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Server.Location = new System.Drawing.Point(6, 19);
            this.Server.Name = "Server";
            this.Server.Size = new System.Drawing.Size(55, 20);
            this.Server.TabIndex = 1;
            this.Server.Text = "Server";
            this.Server.Click += new System.EventHandler(this.Server_Click);
            // 
            // gbParametri
            // 
            this.gbParametri.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.gbParametri.Controls.Add(this.txtPass);
            this.gbParametri.Controls.Add(this.btnTest);
            this.gbParametri.Controls.Add(this.txtUser);
            this.gbParametri.Controls.Add(this.label3);
            this.gbParametri.Controls.Add(this.label2);
            this.gbParametri.Controls.Add(this.txtWS);
            this.gbParametri.Controls.Add(this.label1);
            this.gbParametri.Controls.Add(this.cmbServer);
            this.gbParametri.Controls.Add(this.Server);
            this.gbParametri.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbParametri.Location = new System.Drawing.Point(12, 31);
            this.gbParametri.Name = "gbParametri";
            this.gbParametri.Size = new System.Drawing.Size(371, 250);
            this.gbParametri.TabIndex = 2;
            this.gbParametri.TabStop = false;
            this.gbParametri.Text = "Parametri konekcije";
            // 
            // txtUser
            // 
            this.txtUser.Location = new System.Drawing.Point(109, 114);
            this.txtUser.Name = "txtUser";
            this.txtUser.Size = new System.Drawing.Size(247, 23);
            this.txtUser.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 155);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 20);
            this.label3.TabIndex = 5;
            this.label3.Text = "Password";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 114);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "UserName";
            // 
            // txtWS
            // 
            this.txtWS.Location = new System.Drawing.Point(249, 65);
            this.txtWS.Name = "txtWS";
            this.txtWS.Size = new System.Drawing.Size(107, 23);
            this.txtWS.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "W/S";
            // 
            // chbBaze
            // 
            this.chbBaze.BackColor = System.Drawing.Color.PowderBlue;
            this.chbBaze.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chbBaze.FormattingEnabled = true;
            this.chbBaze.Location = new System.Drawing.Point(6, 22);
            this.chbBaze.Name = "chbBaze";
            this.chbBaze.Size = new System.Drawing.Size(147, 184);
            this.chbBaze.TabIndex = 3;
            this.chbBaze.SelectedIndexChanged += new System.EventHandler(this.checkedListBox1_SelectedIndexChanged);
            // 
            // btnSnimi
            // 
            this.btnSnimi.BackColor = System.Drawing.Color.PaleGreen;
            this.btnSnimi.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSnimi.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSnimi.Location = new System.Drawing.Point(480, 303);
            this.btnSnimi.Name = "btnSnimi";
            this.btnSnimi.Size = new System.Drawing.Size(282, 93);
            this.btnSnimi.TabIndex = 8;
            this.btnSnimi.Text = "SNIMI PARAMETRE ZA BACKUP";
            this.btnSnimi.UseVisualStyleBackColor = false;
            // 
            // btnTest
            // 
            this.btnTest.BackColor = System.Drawing.Color.Aqua;
            this.btnTest.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnTest.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTest.Location = new System.Drawing.Point(47, 188);
            this.btnTest.Name = "btnTest";
            this.btnTest.Size = new System.Drawing.Size(254, 37);
            this.btnTest.TabIndex = 9;
            this.btnTest.Text = "TEST KONEKCIJE";
            this.btnTest.UseVisualStyleBackColor = false;
            // 
            // gbBackup
            // 
            this.gbBackup.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.gbBackup.Controls.Add(this.gbMail);
            this.gbBackup.Controls.Add(this.groupBox2);
            this.gbBackup.Controls.Add(this.gbBaze);
            this.gbBackup.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.gbBackup.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbBackup.Location = new System.Drawing.Point(396, 31);
            this.gbBackup.Name = "gbBackup";
            this.gbBackup.Size = new System.Drawing.Size(416, 250);
            this.gbBackup.TabIndex = 4;
            this.gbBackup.TabStop = false;
            this.gbBackup.Text = "Backup Shedule";
            this.gbBackup.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // gbBaze
            // 
            this.gbBaze.Controls.Add(this.chbBaze);
            this.gbBaze.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbBaze.Location = new System.Drawing.Point(6, 19);
            this.gbBaze.Name = "gbBaze";
            this.gbBaze.Size = new System.Drawing.Size(159, 221);
            this.gbBaze.TabIndex = 5;
            this.gbBaze.TabStop = false;
            this.gbBaze.Text = "Baze :";
            // 
            // txtPass
            // 
            this.txtPass.Location = new System.Drawing.Point(109, 152);
            this.txtPass.Name = "txtPass";
            this.txtPass.Size = new System.Drawing.Size(247, 23);
            this.txtPass.TabIndex = 10;
            // 
            // dtTime
            // 
            this.dtTime.CalendarMonthBackground = System.Drawing.SystemColors.InactiveCaption;
            this.dtTime.CustomFormat = "HH:mm";
            this.dtTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtTime.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.dtTime.Location = new System.Drawing.Point(36, 22);
            this.dtTime.Name = "dtTime";
            this.dtTime.ShowUpDown = true;
            this.dtTime.Size = new System.Drawing.Size(58, 23);
            this.dtTime.TabIndex = 6;
            this.dtTime.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dtTime);
            this.groupBox2.Location = new System.Drawing.Point(224, 19);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(142, 54);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Vreme za backup :";
            // 
            // gbMail
            // 
            this.gbMail.Controls.Add(this.labMail);
            this.gbMail.Controls.Add(this.cbFail);
            this.gbMail.Controls.Add(this.cbDone);
            this.gbMail.Controls.Add(this.txtMail);
            this.gbMail.Location = new System.Drawing.Point(181, 114);
            this.gbMail.Name = "gbMail";
            this.gbMail.Size = new System.Drawing.Size(229, 111);
            this.gbMail.TabIndex = 8;
            this.gbMail.TabStop = false;
            this.gbMail.Text = "E-Mail adresa za  izvestaje :";
            // 
            // txtMail
            // 
            this.txtMail.Location = new System.Drawing.Point(47, 22);
            this.txtMail.Name = "txtMail";
            this.txtMail.Size = new System.Drawing.Size(166, 23);
            this.txtMail.TabIndex = 11;
            // 
            // cbDone
            // 
            this.cbDone.AutoSize = true;
            this.cbDone.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbDone.Location = new System.Drawing.Point(9, 54);
            this.cbDone.Name = "cbDone";
            this.cbDone.Size = new System.Drawing.Size(194, 17);
            this.cbDone.TabIndex = 9;
            this.cbDone.Text = "Šalji obaveštenje za uspeo backup ";
            this.cbDone.UseVisualStyleBackColor = true;
            // 
            // cbFail
            // 
            this.cbFail.AutoSize = true;
            this.cbFail.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbFail.Location = new System.Drawing.Point(9, 77);
            this.cbFail.Name = "cbFail";
            this.cbFail.Size = new System.Drawing.Size(206, 17);
            this.cbFail.TabIndex = 12;
            this.cbFail.Text = "Šalji obaveštenje za neuspeo backup ";
            this.cbFail.UseVisualStyleBackColor = true;
            // 
            // labMail
            // 
            this.labMail.AutoSize = true;
            this.labMail.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labMail.Location = new System.Drawing.Point(6, 27);
            this.labMail.Name = "labMail";
            this.labMail.Size = new System.Drawing.Size(42, 13);
            this.labMail.TabIndex = 5;
            this.labMail.Text = "E-Mail :";
            this.labMail.Click += new System.EventHandler(this.label4_Click);
            // 
            // gbLokacije
            // 
            this.gbLokacije.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.gbLokacije.Controls.Add(this.dgLokacije);
            this.gbLokacije.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbLokacije.Location = new System.Drawing.Point(12, 303);
            this.gbLokacije.Name = "gbLokacije";
            this.gbLokacije.Size = new System.Drawing.Size(418, 208);
            this.gbLokacije.TabIndex = 5;
            this.gbLokacije.TabStop = false;
            this.gbLokacije.Text = "Lokacije za backup";
            // 
            // dgLokacije
            // 
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.LightCyan;
            this.dgLokacije.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            this.dgLokacije.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.dgLokacije.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgLokacije.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.dgLokacije.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            this.dgLokacije.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgLokacije.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Lokacija,
            this.User,
            this.Password});
            this.dgLokacije.EnableHeadersVisualStyles = false;
            this.dgLokacije.GridColor = System.Drawing.SystemColors.Highlight;
            this.dgLokacije.Location = new System.Drawing.Point(0, 39);
            this.dgLokacije.Name = "dgLokacije";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgLokacije.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.dgLokacije.RowHeadersVisible = false;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.PowderBlue;
            this.dgLokacije.RowsDefaultCellStyle = dataGridViewCellStyle9;
            this.dgLokacije.Size = new System.Drawing.Size(401, 150);
            this.dgLokacije.TabIndex = 0;
            this.dgLokacije.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Lokacija
            // 
            this.Lokacija.HeaderText = "Lokacija";
            this.Lokacija.Name = "Lokacija";
            this.Lokacija.Width = 200;
            // 
            // User
            // 
            this.User.HeaderText = "User";
            this.User.Name = "User";
            // 
            // Password
            // 
            this.Password.HeaderText = "Password";
            this.Password.Name = "Password";
            // 
            // btnBackup
            // 
            this.btnBackup.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btnBackup.Font = new System.Drawing.Font("Mistral", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBackup.Location = new System.Drawing.Point(480, 402);
            this.btnBackup.Name = "btnBackup";
            this.btnBackup.Size = new System.Drawing.Size(282, 102);
            this.btnBackup.TabIndex = 1;
            this.btnBackup.Text = "ZAPOČNI BACKUP";
            this.btnBackup.UseVisualStyleBackColor = false;
            // 
            // Test
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(824, 516);
            this.Controls.Add(this.btnBackup);
            this.Controls.Add(this.gbLokacije);
            this.Controls.Add(this.btnSnimi);
            this.Controls.Add(this.gbBackup);
            this.Controls.Add(this.gbParametri);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Test";
            this.Text = "In_Formo Backup Software";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gbParametri.ResumeLayout(false);
            this.gbParametri.PerformLayout();
            this.gbBackup.ResumeLayout(false);
            this.gbBaze.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.gbMail.ResumeLayout(false);
            this.gbMail.PerformLayout();
            this.gbLokacije.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgLokacije)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbServer;
        private System.Windows.Forms.Label Server;
        private System.Windows.Forms.GroupBox gbParametri;
        private System.Windows.Forms.TextBox txtUser;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtWS;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnTest;
        private System.Windows.Forms.Button btnSnimi;
        private System.Windows.Forms.CheckedListBox chbBaze;
        private System.Windows.Forms.GroupBox gbBackup;
        private System.Windows.Forms.TextBox txtPass;
        private System.Windows.Forms.DateTimePicker dtTime;
        private System.Windows.Forms.GroupBox gbBaze;
        private System.Windows.Forms.GroupBox gbMail;
        private System.Windows.Forms.Label labMail;
        private System.Windows.Forms.CheckBox cbFail;
        private System.Windows.Forms.CheckBox cbDone;
        private System.Windows.Forms.TextBox txtMail;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox gbLokacije;
        private System.Windows.Forms.DataGridView dgLokacije;
        private System.Windows.Forms.DataGridViewTextBoxColumn Lokacija;
        private System.Windows.Forms.DataGridViewTextBoxColumn User;
        private System.Windows.Forms.DataGridViewTextBoxColumn Password;
        private System.Windows.Forms.Button btnBackup;
    }
}

