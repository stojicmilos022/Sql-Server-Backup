﻿namespace In_FormoBackup
{
    partial class Test
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.cboServer = new System.Windows.Forms.ComboBox();
            this.Server = new System.Windows.Forms.Label();
            this.gbParametri = new System.Windows.Forms.GroupBox();
            this.txtPass = new System.Windows.Forms.TextBox();
            this.btnTest = new System.Windows.Forms.Button();
            this.txtUser = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtWS = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.clbBaze = new System.Windows.Forms.CheckedListBox();
            this.btnSnimi = new System.Windows.Forms.Button();
            this.gbBackup = new System.Windows.Forms.GroupBox();
            this.gbMail = new System.Windows.Forms.GroupBox();
            this.labMail = new System.Windows.Forms.Label();
            this.chbFail = new System.Windows.Forms.CheckBox();
            this.chbDone = new System.Windows.Forms.CheckBox();
            this.txtMail = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dtpTime = new System.Windows.Forms.DateTimePicker();
            this.gbBaze = new System.Windows.Forms.GroupBox();
            this.gbLokacije = new System.Windows.Forms.GroupBox();
            this.dgLokacije = new System.Windows.Forms.DataGridView();
            this.Lokacija = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.User = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Password = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnBackup = new System.Windows.Forms.Button();
            this.chbXML = new System.Windows.Forms.CheckBox();
            this.chbIzvestaji = new System.Windows.Forms.CheckBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.btnXML = new System.Windows.Forms.Button();
            this.btnIzv = new System.Windows.Forms.Button();
            this.gbParametri.SuspendLayout();
            this.gbBackup.SuspendLayout();
            this.gbMail.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.gbBaze.SuspendLayout();
            this.gbLokacije.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgLokacije)).BeginInit();
            this.SuspendLayout();
            // 
            // cboServer
            // 
            this.cboServer.FormattingEnabled = true;
            this.cboServer.Location = new System.Drawing.Point(109, 19);
            this.cboServer.Name = "cboServer";
            this.cboServer.Size = new System.Drawing.Size(247, 24);
            this.cboServer.Sorted = true;
            this.cboServer.TabIndex = 0;
            this.cboServer.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // Server
            // 
            this.Server.AutoSize = true;
            this.Server.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Server.Location = new System.Drawing.Point(6, 19);
            this.Server.Name = "Server";
            this.Server.Size = new System.Drawing.Size(55, 20);
            this.Server.TabIndex = 1;
            this.Server.Text = "Server";
            this.Server.Click += new System.EventHandler(this.Server_Click);
            // 
            // gbParametri
            // 
            this.gbParametri.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.gbParametri.Controls.Add(this.txtPass);
            this.gbParametri.Controls.Add(this.btnTest);
            this.gbParametri.Controls.Add(this.txtUser);
            this.gbParametri.Controls.Add(this.label3);
            this.gbParametri.Controls.Add(this.label2);
            this.gbParametri.Controls.Add(this.txtWS);
            this.gbParametri.Controls.Add(this.label1);
            this.gbParametri.Controls.Add(this.cboServer);
            this.gbParametri.Controls.Add(this.Server);
            this.gbParametri.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbParametri.Location = new System.Drawing.Point(12, 31);
            this.gbParametri.Name = "gbParametri";
            this.gbParametri.Size = new System.Drawing.Size(371, 250);
            this.gbParametri.TabIndex = 2;
            this.gbParametri.TabStop = false;
            this.gbParametri.Text = "Parametri konekcije";
            // 
            // txtPass
            // 
            this.txtPass.Location = new System.Drawing.Point(109, 152);
            this.txtPass.Name = "txtPass";
            this.txtPass.Size = new System.Drawing.Size(247, 23);
            this.txtPass.TabIndex = 10;
            // 
            // btnTest
            // 
            this.btnTest.BackColor = System.Drawing.Color.Aqua;
            this.btnTest.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnTest.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTest.Location = new System.Drawing.Point(47, 188);
            this.btnTest.Name = "btnTest";
            this.btnTest.Size = new System.Drawing.Size(254, 37);
            this.btnTest.TabIndex = 9;
            this.btnTest.Text = "TEST KONEKCIJE";
            this.btnTest.UseVisualStyleBackColor = false;
            // 
            // txtUser
            // 
            this.txtUser.Location = new System.Drawing.Point(109, 114);
            this.txtUser.Name = "txtUser";
            this.txtUser.Size = new System.Drawing.Size(247, 23);
            this.txtUser.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 155);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 20);
            this.label3.TabIndex = 5;
            this.label3.Text = "Password";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 114);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "UserName";
            // 
            // txtWS
            // 
            this.txtWS.Location = new System.Drawing.Point(249, 65);
            this.txtWS.Name = "txtWS";
            this.txtWS.Size = new System.Drawing.Size(107, 23);
            this.txtWS.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "W/S";
            // 
            // clbBaze
            // 
            this.clbBaze.BackColor = System.Drawing.Color.PowderBlue;
            this.clbBaze.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clbBaze.FormattingEnabled = true;
            this.clbBaze.Location = new System.Drawing.Point(6, 22);
            this.clbBaze.Name = "clbBaze";
            this.clbBaze.Size = new System.Drawing.Size(147, 184);
            this.clbBaze.TabIndex = 3;
            this.clbBaze.SelectedIndexChanged += new System.EventHandler(this.checkedListBox1_SelectedIndexChanged);
            // 
            // btnSnimi
            // 
            this.btnSnimi.BackColor = System.Drawing.Color.PaleGreen;
            this.btnSnimi.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSnimi.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSnimi.Location = new System.Drawing.Point(480, 417);
            this.btnSnimi.Name = "btnSnimi";
            this.btnSnimi.Size = new System.Drawing.Size(282, 38);
            this.btnSnimi.TabIndex = 8;
            this.btnSnimi.Text = "SNIMI PARAMETRE ZA BACKUP";
            this.btnSnimi.UseVisualStyleBackColor = false;
            // 
            // gbBackup
            // 
            this.gbBackup.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.gbBackup.Controls.Add(this.gbMail);
            this.gbBackup.Controls.Add(this.groupBox2);
            this.gbBackup.Controls.Add(this.gbBaze);
            this.gbBackup.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.gbBackup.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbBackup.Location = new System.Drawing.Point(396, 31);
            this.gbBackup.Name = "gbBackup";
            this.gbBackup.Size = new System.Drawing.Size(416, 250);
            this.gbBackup.TabIndex = 4;
            this.gbBackup.TabStop = false;
            this.gbBackup.Text = "Backup Shedule";
            this.gbBackup.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // gbMail
            // 
            this.gbMail.Controls.Add(this.labMail);
            this.gbMail.Controls.Add(this.chbFail);
            this.gbMail.Controls.Add(this.chbDone);
            this.gbMail.Controls.Add(this.txtMail);
            this.gbMail.Location = new System.Drawing.Point(181, 114);
            this.gbMail.Name = "gbMail";
            this.gbMail.Size = new System.Drawing.Size(229, 111);
            this.gbMail.TabIndex = 8;
            this.gbMail.TabStop = false;
            this.gbMail.Text = "E-Mail adresa za  izvestaje :";
            // 
            // labMail
            // 
            this.labMail.AutoSize = true;
            this.labMail.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labMail.Location = new System.Drawing.Point(6, 27);
            this.labMail.Name = "labMail";
            this.labMail.Size = new System.Drawing.Size(42, 13);
            this.labMail.TabIndex = 5;
            this.labMail.Text = "E-Mail :";
            this.labMail.Click += new System.EventHandler(this.label4_Click);
            // 
            // chbFail
            // 
            this.chbFail.AutoSize = true;
            this.chbFail.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chbFail.Location = new System.Drawing.Point(9, 77);
            this.chbFail.Name = "chbFail";
            this.chbFail.Size = new System.Drawing.Size(206, 17);
            this.chbFail.TabIndex = 12;
            this.chbFail.Text = "Šalji obaveštenje za neuspeo backup ";
            this.chbFail.UseVisualStyleBackColor = true;
            // 
            // chbDone
            // 
            this.chbDone.AutoSize = true;
            this.chbDone.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chbDone.Location = new System.Drawing.Point(9, 54);
            this.chbDone.Name = "chbDone";
            this.chbDone.Size = new System.Drawing.Size(194, 17);
            this.chbDone.TabIndex = 9;
            this.chbDone.Text = "Šalji obaveštenje za uspeo backup ";
            this.chbDone.UseVisualStyleBackColor = true;
            // 
            // txtMail
            // 
            this.txtMail.Location = new System.Drawing.Point(47, 22);
            this.txtMail.Name = "txtMail";
            this.txtMail.Size = new System.Drawing.Size(166, 23);
            this.txtMail.TabIndex = 11;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dtpTime);
            this.groupBox2.Location = new System.Drawing.Point(224, 19);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(142, 54);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Vreme za backup :";
            // 
            // dtpTime
            // 
            this.dtpTime.CalendarMonthBackground = System.Drawing.SystemColors.InactiveCaption;
            this.dtpTime.CustomFormat = "HH:mm";
            this.dtpTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpTime.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.dtpTime.Location = new System.Drawing.Point(36, 22);
            this.dtpTime.Name = "dtpTime";
            this.dtpTime.ShowUpDown = true;
            this.dtpTime.Size = new System.Drawing.Size(58, 23);
            this.dtpTime.TabIndex = 6;
            this.dtpTime.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // gbBaze
            // 
            this.gbBaze.Controls.Add(this.clbBaze);
            this.gbBaze.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbBaze.Location = new System.Drawing.Point(6, 19);
            this.gbBaze.Name = "gbBaze";
            this.gbBaze.Size = new System.Drawing.Size(159, 221);
            this.gbBaze.TabIndex = 5;
            this.gbBaze.TabStop = false;
            this.gbBaze.Text = "Baze :";
            // 
            // gbLokacije
            // 
            this.gbLokacije.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.gbLokacije.Controls.Add(this.dgLokacije);
            this.gbLokacije.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbLokacije.Location = new System.Drawing.Point(12, 303);
            this.gbLokacije.Name = "gbLokacije";
            this.gbLokacije.Size = new System.Drawing.Size(418, 208);
            this.gbLokacije.TabIndex = 5;
            this.gbLokacije.TabStop = false;
            this.gbLokacije.Text = "Lokacije za backup";
            // 
            // dgLokacije
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightCyan;
            this.dgLokacije.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgLokacije.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.dgLokacije.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgLokacije.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.dgLokacije.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            this.dgLokacije.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgLokacije.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Lokacija,
            this.User,
            this.Password});
            this.dgLokacije.EnableHeadersVisualStyles = false;
            this.dgLokacije.GridColor = System.Drawing.SystemColors.Highlight;
            this.dgLokacije.Location = new System.Drawing.Point(0, 39);
            this.dgLokacije.Name = "dgLokacije";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgLokacije.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgLokacije.RowHeadersVisible = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.PowderBlue;
            this.dgLokacije.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dgLokacije.Size = new System.Drawing.Size(401, 150);
            this.dgLokacije.TabIndex = 0;
            this.dgLokacije.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Lokacija
            // 
            this.Lokacija.HeaderText = "Lokacija";
            this.Lokacija.Name = "Lokacija";
            this.Lokacija.Width = 200;
            // 
            // User
            // 
            this.User.HeaderText = "User";
            this.User.Name = "User";
            // 
            // Password
            // 
            this.Password.HeaderText = "Password";
            this.Password.Name = "Password";
            // 
            // btnBackup
            // 
            this.btnBackup.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btnBackup.Font = new System.Drawing.Font("Mistral", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBackup.Location = new System.Drawing.Point(480, 461);
            this.btnBackup.Name = "btnBackup";
            this.btnBackup.Size = new System.Drawing.Size(282, 43);
            this.btnBackup.TabIndex = 1;
            this.btnBackup.Text = "ZAPOČNI BACKUP";
            this.btnBackup.UseVisualStyleBackColor = false;
            // 
            // chbXML
            // 
            this.chbXML.AutoSize = true;
            this.chbXML.Checked = true;
            this.chbXML.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chbXML.Location = new System.Drawing.Point(436, 370);
            this.chbXML.Name = "chbXML";
            this.chbXML.Size = new System.Drawing.Size(88, 17);
            this.chbXML.TabIndex = 9;
            this.chbXML.Text = "Backup XML";
            this.chbXML.UseVisualStyleBackColor = true;
            this.chbXML.CheckedChanged += new System.EventHandler(this.chbXML_CheckedChanged);
            // 
            // chbIzvestaji
            // 
            this.chbIzvestaji.AutoSize = true;
            this.chbIzvestaji.Checked = true;
            this.chbIzvestaji.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chbIzvestaji.Location = new System.Drawing.Point(436, 326);
            this.chbIzvestaji.Name = "chbIzvestaji";
            this.chbIzvestaji.Size = new System.Drawing.Size(104, 17);
            this.chbIzvestaji.TabIndex = 10;
            this.chbIzvestaji.Text = "Backup Izvestaji";
            this.chbIzvestaji.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(577, 323);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(235, 20);
            this.textBox1.TabIndex = 11;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(577, 367);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(235, 20);
            this.textBox2.TabIndex = 12;
            // 
            // btnXML
            // 
            this.btnXML.Location = new System.Drawing.Point(539, 364);
            this.btnXML.Name = "btnXML";
            this.btnXML.Size = new System.Drawing.Size(32, 23);
            this.btnXML.TabIndex = 14;
            this.btnXML.Text = "button2";
            this.btnXML.UseVisualStyleBackColor = true;
            // 
            // btnIzv
            // 
            this.btnIzv.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnIzv.Image = global::In_FormoBackup.Properties.Resources.Icon1;
            this.btnIzv.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnIzv.Location = new System.Drawing.Point(539, 321);
            this.btnIzv.Name = "btnIzv";
            this.btnIzv.Size = new System.Drawing.Size(32, 23);
            this.btnIzv.TabIndex = 13;
            this.btnIzv.UseVisualStyleBackColor = true;
            this.btnIzv.Click += new System.EventHandler(this.btnIzv_Click);
            // 
            // Test
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(824, 516);
            this.Controls.Add(this.btnXML);
            this.Controls.Add(this.btnIzv);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.chbIzvestaji);
            this.Controls.Add(this.chbXML);
            this.Controls.Add(this.btnBackup);
            this.Controls.Add(this.gbLokacije);
            this.Controls.Add(this.btnSnimi);
            this.Controls.Add(this.gbBackup);
            this.Controls.Add(this.gbParametri);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Test";
            this.Text = "In_Formo Backup Software";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gbParametri.ResumeLayout(false);
            this.gbParametri.PerformLayout();
            this.gbBackup.ResumeLayout(false);
            this.gbMail.ResumeLayout(false);
            this.gbMail.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.gbBaze.ResumeLayout(false);
            this.gbLokacije.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgLokacije)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cboServer;
        private System.Windows.Forms.Label Server;
        private System.Windows.Forms.GroupBox gbParametri;
        private System.Windows.Forms.TextBox txtUser;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtWS;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnTest;
        private System.Windows.Forms.Button btnSnimi;
        private System.Windows.Forms.CheckedListBox clbBaze;
        private System.Windows.Forms.GroupBox gbBackup;
        private System.Windows.Forms.TextBox txtPass;
        private System.Windows.Forms.DateTimePicker dtpTime;
        private System.Windows.Forms.GroupBox gbBaze;
        private System.Windows.Forms.GroupBox gbMail;
        private System.Windows.Forms.Label labMail;
        private System.Windows.Forms.CheckBox chbFail;
        private System.Windows.Forms.CheckBox chbDone;
        private System.Windows.Forms.TextBox txtMail;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox gbLokacije;
        private System.Windows.Forms.DataGridView dgLokacije;
        private System.Windows.Forms.DataGridViewTextBoxColumn Lokacija;
        private System.Windows.Forms.DataGridViewTextBoxColumn User;
        private System.Windows.Forms.DataGridViewTextBoxColumn Password;
        private System.Windows.Forms.Button btnBackup;
        private System.Windows.Forms.CheckBox chbXML;
        private System.Windows.Forms.CheckBox chbIzvestaji;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button btnIzv;
        private System.Windows.Forms.Button btnXML;
    }
}

